import React from 'react';
import videoHeader from '../../video/header_video.mp4'
import { Container, Row, Col, Button, useTheme, Text, Spacer } from '@nextui-org/react';
import './header.css';

const Header = () => {
  const { theme } = useTheme();

  return (
    <div>
      <video className="toto" autoPlay muted loop id="myVideo">
        <source src={videoHeader} type="video/mp4" />
      </video>
      <Container className="container-css">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Valorant_logo_-_pink_color_version.svg/800px-Valorant_logo_-_pink_color_version.svg.png" height={50} width={70} />
        <Spacer y={5} />
        <Text h1>Découvrez des trucs grâce à moi <br />
          et pleins d'autres choses sur <br />
          <Text h1 css={{ color: theme.colors.primary.value }}>Oppoxa</Text>
        </Text>
        <Spacer y={1} />
        <Button>Découvrir</Button>
      </Container>
    </div>
  );
}

export default Header;
