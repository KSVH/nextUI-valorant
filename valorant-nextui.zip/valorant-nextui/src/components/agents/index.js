import React from 'react';
import videoHeader from '../../video/header_video.mp4'
import { Container, Row, Col, Button, useTheme, Text, Spacer, Grid, Card, Avatar } from '@nextui-org/react';
import './agents.css';

const Agents = () => {
  const { theme } = useTheme();

  const MockItem = ({ roleImg, role, name, agent }) => {
    return (
      <Card isHoverable isPressable css={{ backgroundColor: theme.colors.secondary.value }}>
        <Card.Body style={{ backgroundImage: `url(${agent})` }} className="agent-css">
          <Row>
            <Avatar
              size="xs"
              color="primary"
              src={roleImg} />
            <Text h6 size={15} css={{ mt: 0, textTransform: "uppercase", color: theme.colors.primary.value }}>
              {role}
            </Text>
          </Row>

          <Text h5 size={20} color="white" css={{ mt: 0 }}>
            {name}
          </Text>
        </Card.Body>
      </Card>
    );
  };

  return (
    <div>
      <Container fluid className="container-agents">
        <Text h2>Les agents</Text>
        <Grid.Container gap={2} justify="center">
          <Grid xs={6} sm={3}>
            <MockItem roleImg="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt213441880cf2cdf5/5eaa06851b51e36d7c1b61d4/Duelist.png" role="Contrôleur" name="Viper" agent="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/bltc825c6589eda7717/5eb7cdc6ee88132a6f6cfc25/V_AGENTS_587x900_Viper.png" />
          </Grid>
          <Grid xs={6} sm={3}>
            <MockItem role="Sentinelle" name="Killjoy" agent="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt53405c26141beff8/5f21fda671ec397ef9bf0894/V_AGENTS_587x900_KillJoy_.png" />
          </Grid>
          <Grid xs={6} sm={3}>
            <MockItem role="Contrôleur" name="Omen" agent="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt4e5af408cc7a87b5/5eb7cdc17bedc8627eff8deb/V_AGENTS_587x900_Omen.png" />
          </Grid>
          <Grid xs={6} sm={3}>
            <MockItem roleImg="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt213441880cf2cdf5/5eaa06851b51e36d7c1b61d4/Duelist.png" role="Duelliste" name="Neon" agent="https://images.contentstack.io/v3/assets/bltb6530b271fddd0b1/blt8093ba7b5e84ed05/61d8a63ddea73a236fc56d12/Neon_KeyArt-Web.png" />
          </Grid>
        </Grid.Container>
      </Container>
    </div>
  );
}

export default Agents;
