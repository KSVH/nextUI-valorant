import { createTheme, NextUIProvider, Text } from "@nextui-org/react"
import * as React from 'react';
import Agents from "./components/agents";
import Header from "./components/header";

const theme = createTheme({
  type: "dark", // it could be "light" or "dark"
  theme: {
    colors: {
      primary: '#FF4654',
      secondary: '#0F1923',
      grey: '#111111',
      background: 'white'
    },
    space: {
      small: '50px'
    },
    fonts: {
      title: '36px'
    }
  }
})

const App = () => {
  return (
    <NextUIProvider theme={theme}>
      <Header />
      <Agents />
    </NextUIProvider>
  )
}
export default App;
